#ifndef CHECK_HPP
#define CHECK_HPP
#define MAX 1000



template<typename P> 
class Check{
  private:
    P v[MAX+1];
    int i;
    int f;
    int n;
  public:
    Check(): i(0), f(0), n(MAX+1){

    }
    bool checkIn(P valor){
			if( ( (f+1) % n) == i){
				return false;
			}
			v[f] = valor;
			f = (f+1) % n;
			return true;
		}
    void imprime(){
      std:: cout << "Hóspedes no hotel:" << std :: endl;
      for(int k=i-1;(k+1)%n != f;k=(k+1)%n){
		
    		std::cout << v[k+1] << std::endl;
        
			}
    }

    P checkOut(bool *erro= NULL){
			
			if(i==f){
        if(erro)
          *erro = true;
				return v[0];
			}
			P temp = v[i];

	  	i = (i+1) % n;
      if(erro)
          *erro = false;
			
			return temp;
		}

    

};


#endif