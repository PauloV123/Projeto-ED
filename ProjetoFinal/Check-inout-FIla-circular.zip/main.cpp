#include <iostream>
#include "Check.hpp"


using namespace std;
int main() {
  Check<int> L;
  int x = 0;
  int resp;
  //menu

  do{
    if(x >= 1000) // quantidade maxima de hóspedes do hotel
      x = 0; // coloquei os hóspedes pra serem contados por números
    cout << "" << endl;
    cout << "" << endl;
    cout << "-------MENU--------"<< endl;
    cout<<"1  -   Check In" << endl; // insere
    cout<<"2  -   Check Out" << endl; // remove 
    cout<<"3  -   Hóspedes" << endl; // imprime
    cout<<"4  -   Sair" << endl; // sai do menu
    cout << "----------------"<< endl;
    cin >> resp;
    cout << "" << endl;
    if(resp == 1){
      L.checkIn(x);
      x++;
      cout << "Check In feito com sucesso!" << endl;
    }else if(resp == 2){
      L.checkOut();
      cout << "Check Out feito com sucesso!" << endl;
    }else if(resp == 3){
      L.imprime();
    }else{
      cout << "Parando programa"<<endl;
    }
    
  }while(resp < 4);
 

  return 0;
  
}