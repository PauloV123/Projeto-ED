#include <iostream>

#include "Pilha.hpp"

using namespace std;
int main() {
  Pilha<int> T;
  for(int i = 0;i<1001;i++){
    T.empilha(i);
  }
  
  cout <<"Quarto que a faxineira está:" << endl;
  int x;
  while(T.desempilha(&x)){
    cout <<"Quarto: "<<  x << endl;
  }

}